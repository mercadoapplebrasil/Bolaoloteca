import sys
sys.path.insert(0, "/home/claude/scripts"); import somb
# Gera o modelo do Bolão Loteca v2 a partir do site atual (mantém visual e textos).
src = open("/home/claude/scripts/bl_original.html", encoding="utf-8").read()   # cópia do site antigo (fonte do modelo)
i_script = src.index("<script>\n/* ====== EDITAR AQUI")
html, js = src[:i_script], src[i_script:]

def troca(texto, a, b, n=1):
    assert texto.count(a) == n, (texto.count(a), a[:80])
    return texto.replace(a, b)

UR = ("U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,U+0308,U+0329,"
      "U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD")
fontes = "".join(
    f'@font-face{{font-family:{fam};font-style:normal;font-weight:{w};font-display:swap;src:url(/fonts/{arq}.woff2) format("woff2");unicode-range:{UR}}}\n'
    for fam, w, arq in [("Oswald", 500, "oswald-latin-500-normal"), ("Oswald", 700, "oswald-latin-700-normal"),
                        ("Inter", 400, "inter-latin-400-normal"), ("Inter", 600, "inter-latin-600-normal"),
                        ("Inter", 700, "inter-latin-700-normal")])

# ---------- cabeça ----------
html = troca(html, '<title>Bolão Loteca · bolão da Loteria Esportiva</title>\n',
             '<title>Bolão Loteca · bolão da Loteria Esportiva</title>\n%%ROBOTS%%')
html = troca(html, '''<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500;700&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
''', '''<link rel="preload" href="/fonts/oswald-latin-700-normal.woff2" as="font" type="font/woff2" crossorigin>
<script type="application/ld+json">{"@context":"https://schema.org","@type":"WebSite","name":"Bolão Loteca","alternateName":"Bolão da Loteria Esportiva","url":"https://bolaoloteca.com.br/","inLanguage":"pt-BR"}</script>
<style>
''' + fontes)
for a in ['href="favicon.svg?v=3"', 'href="favicon-32.png?v=3"', 'href="apple-touch-icon.png?v=3"', 'href="manifest.webmanifest"', 'src="torcedor-premiado.jpg"']:
    k, v = a.split('="'); html = troca(html, a, f'{k}="/{v}')

# ---------- estilos novos ----------
html = troca(html, "footer a{color:var(--rosa)}\n</style>", """footer a{color:var(--rosa)}
.rest .ult{display:inline-block;margin-left:8px;background:#fff;color:var(--red2);font-size:13px;font-weight:800;padding:2px 9px;border-radius:99px;text-transform:uppercase;letter-spacing:.04em;vertical-align:2px}
.barra2{height:9px;background:rgba(0,0,0,.25);border-radius:99px;margin-top:8px;overflow:hidden}
.barra2 i{display:block;height:100%;background:var(--gold);border-radius:99px}
.btn.s2{background:rgba(0,0,0,.2);color:#fff;gap:10px;font-size:17px;min-height:52px}
.btn.s2 svg{width:20px;height:20px;flex:none}
.fim{margin:16px 0 0;padding:12px 14px;background:rgba(0,0,0,.22);border-radius:12px;font-weight:700}
.conf{display:flex;align-items:center;gap:14px;background:var(--bg2);border:2px solid var(--line);border-radius:16px;padding:14px 16px;margin:0 0 16px}
.conf b{font-family:Oswald,Impact,sans-serif;font-size:34px;line-height:1;color:var(--gold);white-space:nowrap}
.conf span{font-size:17px;font-weight:600;line-height:1.35}
.conf.prem{border-color:var(--gold);background:#2A2410}
.vol i.res{box-shadow:0 0 0 3px var(--gold)}
.vol{flex-wrap:wrap}.vol span{white-space:nowrap}
.vol b{margin-left:6px;font-size:14px;white-space:nowrap}
.vol b.ok{color:#5BD48A}.vol b.er{color:var(--mut)}
dialog.av{border:1px solid var(--line);border-radius:18px;padding:0;width:min(440px,calc(100vw - 28px));background:var(--bg2);color:var(--tx);box-shadow:0 24px 60px rgba(0,0,0,.6)}
dialog.av::backdrop{background:rgba(0,0,0,.72)}
.av .in{padding:24px 20px 18px}
.av h2{margin:0 0 6px;font-size:26px}
.av p{margin:0 0 14px;font-size:17px;color:var(--mut)}
.av .alvo{background:#2A1414;border:2px dashed var(--red);border-radius:12px;padding:14px 16px;margin:0 0 16px}
.av .alvo b{display:block;font-size:21px;line-height:1.25;color:#fff}
.av .alvo span{display:block;font-size:17px;margin-top:2px}
.av .alvo small{display:block;font-size:14px;color:var(--mut);margin-top:6px}
.av .acts2{display:grid;gap:8px}
.av button.fx{background:none;border:0;font:inherit;font-size:16px;font-weight:700;color:var(--mut);min-height:44px;cursor:pointer;text-decoration:underline}
.av p.cod{margin:12px 0 0;font-size:14px;text-align:center}
.av a.avz{display:block;text-align:center;font-size:15px;color:var(--rosa);font-weight:700;margin-top:6px}
</style>""")

# ---------- corpo: conteúdo já escrito no HTML (pré-render) ----------
html = troca(html, '<noscript><p style="padding:18px">Ative o JavaScript do navegador para ver a grade e dar seu palpite.</p></noscript>\n', '')
html = troca(html, '<p class="eye" id="hEye">Loteca da semana</p>', '<p class="eye" id="hEye">%%HEYE%%</p>')
html = troca(html, '<small id="hConc"></small>', '<small id="hConc">%%HCONC%%</small>')
html = troca(html, '<div class="d hp" id="hPremio"></div>', '<div class="d hp" id="hPremio">%%HPREMIO%%</div>')
html = troca(html, '<p class="hs" id="hSub"></p>', '<p class="hs" id="hSub">%%HSUB%%</p>')
html = troca(html, '<div class="bolao" id="bolaoBox"></div>', '<div class="bolao" id="bolaoBox">%%BOLAO%%</div>')
html = troca(html, '<p class="sub" id="gradeSub">1 = time da casa · X = empate · 2 = visitante. Vale o placar do tempo normal, sem prorrogação nem pênaltis.</p>',
             '%%CONF%%\n  <p class="sub" id="gradeSub">%%GRADESUB%%</p>')
html = troca(html, '<ol class="jogos" id="listaGrade"></ol>', '<ol class="jogos" id="listaGrade">%%GRADE%%</ol>')
# palpites seguem guardados para o futuro: escondidos já no HTML (o script mostra se ligar)
for sec in ['<section class="w" id="palpite">', '<section class="w" id="povo">', '<section class="w" id="ranking">', '<section class="w conta" id="conta">']:
    html = troca(html, sec, sec[:-1] + ' hidden>')
n = html.count("data-palp"); html = html.replace("data-palp", "data-palp hidden"); assert n == 6, n
html = troca(html, '<div class="fixa" id="fixa" hidden>', '''<dialog class="av" id="aviso" aria-labelledby="avT">
  <div class="in">
    <h2 id="avT">Antes de ir para a Caixa</h2>
    <p>O link abre a página da lotérica com todos os bolões. Procure este:</p>
    <div class="alvo"><b id="avA"></b><span id="avB"></span><small id="avC"></small></div>
    <div class="acts2">
      <a class="btn p" id="avIr" href="https://www.loteriasonline.caixa.gov.br/silce-web/#/bolao-caixa/001926" target="_blank" rel="noopener">Ir para a Caixa</a>
      <button class="fx" type="button" id="avX">Voltar</button>
    </div>
    <p class="cod">Na Caixa, a lotérica aparece como <b>Vilela &amp; Granhani Ltda Me</b> · código <b>001926</b></p>
    <a class="avz" id="avZ" href="https://wa.me/5511914819638" target="_blank" rel="noopener">Não achou? Chame no WhatsApp</a>
  </div>
</dialog>
<div class="fixa" id="fixa" hidden>''')

# ---------- script ----------
i0 = js.index("var LOTECA = {"); i1 = js.index("/* ====== FIM DA EDIÇÃO ====== */")
js = js[:i0] + "var LOTECA;   // vem do dados.json\n" + js[i1:]
js = troca(js, "<script>\n/* ====== EDITAR AQUI", '<script type="application/json" id="dados">%%DADOS%%</script>\n<script>\n/* ====== EDITAR AQUI')
js = troca(js, "/* modo de teste:", "function iniciar(){\n/* modo de teste:")
js = troca(js, '''if(!PALP){ ["palpite","povo","ranking","conta"].forEach(function(id){ document.getElementById(id).hidden=true; });
  Array.prototype.forEach.call(document.querySelectorAll("[data-palp]"),function(x){ x.hidden=true; }); }''',
'''if(PALP){ ["palpite","povo","ranking","conta"].forEach(function(id){ document.getElementById(id).hidden=false; });
  Array.prototype.forEach.call(document.querySelectorAll("[data-palp]"),function(x){ x.hidden=false; }); }''')
js = troca(js, 'RES ? "Jogos encerrados. Veja o resultado e o ranking."',
           'RES ? (PALP ? "Jogos encerrados. Veja o resultado e o ranking." : "Jogos encerrados. Veja a conferência do bolão.")')
# card do bolão: barra de cotas, últimas cotas, compartilhar, aviso da Caixa, encerrado/esgotado
js = troca(js, '''  var bx=document.getElementById("bolaoBox"), b=LOTECA.bolao;
''', '''  var bx=document.getElementById("bolaoBox"), b=LOTECA.bolao; bx.textContent="";
''')
js = troca(js, '''  if(b.restam!=null) bx.appendChild(el("div","rest", b.restam>0 ? "Restam "+b.restam+" de "+b.cotas+" cotas" : "Esgotado"));
''', '''  var ESG = b.restam===0, ENC = !!RES || (FECHA && Date.now()>=FECHA.getTime());
  if(b.restam!=null){ var rr=el("div","rest", ESG ? "Esgotado" : (b.restam===1?"Resta 1 de ":"Restam "+b.restam+" de ")+b.cotas+" cotas");
    if(!ESG && !ENC && b.restam<=2) rr.appendChild(el("span","ult","Últimas cotas"));
    bx.appendChild(rr);
    var vend=b.cotas-b.restam; if(!ESG && vend>0){ var br=el("div","barra2"), f=el("i"); br.setAttribute("aria-hidden","true"); f.style.width=Math.max(6,Math.round(vend/b.cotas*100))+"%"; br.appendChild(f); bx.appendChild(br); } }
''')
js = troca(js, '''  var acts=el("div","acts");
  var w=el("a","btn w2","Reservar pelo WhatsApp"); w.href=wa("Olá! Quero reservar uma cota do bolão da Loteca "+LOTECA.concurso+" ("+b.formato+"), cota de "+b.valor+"."); w.rel="noopener";
  var o=el("a","btn o2","Comprar on-line"); o.href=CONFIG.linkCaixa; o.target="_blank"; o.rel="noopener";
  acts.appendChild(w); acts.appendChild(o); bx.appendChild(acts);
''', '''  var acts=el("div","acts");
  if(ENC){ bx.appendChild(el("p","fim", RES ? "Bolão encerrado. Veja abaixo a conferência dos 14 jogos." : "Bolão encerrado. A conferência sai aqui depois dos jogos.")); }
  else if(ESG){ var w1=el("a","btn w2","Me avise do próximo bolão"); w1.href=wa("Olá! O bolão da Loteca "+LOTECA.concurso+" esgotou. Me avisa do próximo?"); w1.rel="noopener"; acts.appendChild(w1); }
  else {
    var w=el("a","btn w2","Reservar pelo WhatsApp"); w.href=wa("Olá! Quero reservar uma cota do bolão da Loteca "+LOTECA.concurso+" ("+b.formato+"), cota de "+b.valor+"."); w.rel="noopener";
    var o=el("a","btn o2","Comprar on-line"); o.href=CONFIG.linkCaixa; o.target="_blank"; o.rel="noopener"; o.setAttribute("data-cx","");
    acts.appendChild(w); acts.appendChild(o); }
  var s=el("button","btn s2"); s.type="button"; s.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15V3M7 8l5-5 5 5M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  s.appendChild(document.createTextNode("Mandar pros amigos"));
  s.addEventListener("click",function(){ compartilhar({title:"Bolão da Loteca "+LOTECA.concurso, text:"Bolão da Loteca "+LOTECA.concurso+(LOTECA.premio?" · prêmio estimado "+LOTECA.premio:"")+" · "+b.formato+" · "+b.cotas+" cotas de "+b.valor+".", url:CONFIG.site+"/"}); });
  acts.appendChild(s); bx.appendChild(acts);
''')
js = troca(js, '  if(LOTECA.prazos){', '  if(LOTECA.prazos && !ENC){')
js = troca(js, '  bx.appendChild(el("p","nota","Valor da cota no balcão.', '  if(!ENC && !ESG) bx.appendChild(el("p","nota","Valor da cota no balcão.')
js = troca(js, 'var lg=document.getElementById("listaGrade");\n', 'var lg=document.getElementById("listaGrade"); lg.textContent="";\n')
# conferência automática quando os resultados entram
js = troca(js, '''    ["1","X","2"].forEach(function(o){ v.appendChild(el("i", j.b.indexOf(o)>=0?"on":"", o)); });
''', '''    ["1","X","2"].forEach(function(o){ v.appendChild(el("i", ((j.b.indexOf(o)>=0?"on":"")+(j.r===o?" res":"")).trim(), o)); });
    if(j.r){ var ok=j.b.indexOf(j.r)>=0; v.appendChild(el("b", ok?"ok":"er", ok?"✓ Acertamos":"✗ Erramos")); }
''')
js = troca(js, '''    if(t) li[i].appendChild(t); });
''', '''    if(t && !j.r) li[i].appendChild(t); });
  var com=J.filter(function(j){return j.r&&j.b;}), ac=com.filter(function(j){return j.b.indexOf(j.r)>=0;}).length, cf=document.getElementById("conf");
  if(cf && com.length){ cf.textContent=""; cf.hidden=false; var fim=com.length===J.length;
    cf.appendChild(el("b",null, fim ? ac+" pontos" : ac+" de "+com.length));
    cf.appendChild(el("span",null, !fim ? "acertos do nosso bolão até agora."
      : ac===14 ? "PREMIADO! Nosso bolão fez 14 pontos."
      : ac===13 ? (LOTECA.especial ? "13 pontos: leva o prêmio se ninguém fizer 14." : "PREMIADO! Nosso bolão fez 13 pontos.")
      : "Não foi dessa vez. Bora pro próximo!"));
    cf.classList.toggle("prem", fim && ac>=13); }
''')
js = troca(js, "carregar(); tique(); setInterval(tique,30000); setInterval(function(){ if(aberto()) carregar(); },120000);\n</script>",
'''carregar(); tique(); setInterval(tique,30000); setInterval(function(){ if(aberto()) carregar(); },120000);

/* aviso antes de ir para a Caixa */
var av=document.getElementById("aviso");
document.getElementById("avIr").href=CONFIG.linkCaixa;
document.getElementById("avZ").href=wa("Olá! Não achei o bolão da Loteca "+LOTECA.concurso+" na página da Caixa, pode me ajudar?");
if(av && av.showModal){
  document.addEventListener("click",function(e){ var o=e.target.closest&&e.target.closest("[data-cx]"); if(!o) return; e.preventDefault();
    var b=LOTECA.bolao;
    document.getElementById("avA").textContent="Loteca "+LOTECA.concurso+(b?" · "+(b.app||b.valor+" + tarifa da Caixa"):"");
    document.getElementById("avB").textContent=b?b.formato:"";
    document.getElementById("avC").textContent=b?b.cotas+" cotas":"";
    av.showModal(); });
  document.getElementById("avX").addEventListener("click",function(){av.close();});
  document.getElementById("avIr").addEventListener("click",function(){av.close();});
  av.addEventListener("click",function(e){if(e.target===av)av.close();});
}
}
function compartilhar(x){ if(navigator.share){ navigator.share(x).catch(function(){}); return; }
  window.open("https://wa.me/?text="+encodeURIComponent(x.text+"\\n"+x.url),"_blank","noopener"); }
/* os dados vêm do dados.json; se ele demorar, usa a cópia que já veio na página */
(function(){ var EMB=JSON.parse(document.getElementById("dados").textContent), foi=false;
  function vai(d){ if(foi) return; foi=true; LOTECA=d; iniciar(); }
  if(window.fetch) fetch("dados.json",{cache:"no-store"}).then(function(r){ if(!r.ok) throw 0; return r.json(); }).then(vai,function(){ vai(EMB); });
  setTimeout(function(){ vai(EMB); }, window.fetch?2500:0);
})();
</script>''')
# ---------- Dona Zebra animada, com som ----------
zsvg = open("/home/claude/scripts/bl_zebra.svg", encoding="utf-8").read()
zcss = open("/home/claude/scripts/bl_zebra.css", encoding="utf-8").read()
i0 = html.index('<div class="zebra"><svg viewBox="0 0 300 320"'); i1 = html.index('</svg></div>', i0) + len('</svg></div>')
html = html[:i0] + '<button class="zebra" id="dz" type="button" aria-label="Dona Zebra: toque para ouvir">' + zsvg + '</button>' + somb.html(rotulo=False, classe="min") + html[i1:]
VCSS = """
.vit{display:grid;gap:10px;margin:0 0 18px}
.vt{margin:0;font-size:14px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--rosa)}
.vi{display:grid;grid-template-columns:1fr auto;gap:2px 12px;align-items:baseline;background:var(--bg2);border:1px solid var(--line);border-left:6px solid var(--c,#D5261F);border-radius:14px;padding:12px 14px;text-decoration:none;color:var(--tx)}
.vi:hover{border-color:var(--rosa)}
.vn{font-weight:700;font-size:18px;line-height:1.25}
.vp{font-family:Oswald,Impact,sans-serif;font-size:20px;color:var(--gold);text-align:right;white-space:nowrap}
.vd{grid-column:1/-1;font-size:15px;color:var(--mut)}
"""
html = troca(html, "</style>\n</head>", somb.CSS + zcss + VCSS + "</style>\n</head>")
html = troca(html, '<p class="sub">Mega-Sena, +Milionária, Quina e Mega da Virada também têm bolão.</p>\n',
             '<p class="sub">Mega-Sena, +Milionária, Quina e Mega da Virada também têm bolão.</p>\n  <div class="vit" id="vit" hidden></div>\n')
ZJS = open("/home/claude/scripts/bl_zebra_ctl.js", encoding="utf-8").read()
VJS = open("/home/claude/scripts/vitrine.js", encoding="utf-8").read()
js = troca(js, "/* os dados vêm do dados.json;", VJS
           + 'vitrine(document.getElementById("vit"), {excluir:["loteca"], max:4, titulo:"Abertos agora no Loterias 24 Horas",\n'
           + '  /* as cotas que restam vêm do Loterias 24 Horas (fonte única, conferida na Caixa) */\n'
           + '  aoCarregar:function(D){ var bo=LOTECA.bolao; if(!bo) return; var m=(D.boloes||[]).filter(function(x){return x.lot==="loteca"&&x.concurso===LOTECA.concurso;})[0]; if(!m||m.restam===bo.restam) return; bo.restam=m.restam;\n'
           + '    var r=document.querySelector("#bolaoBox .rest"); if(r&&r.firstChild) r.firstChild.nodeValue=m.restam===0?"Esgotado":(m.restam===1?"Resta 1 de ":"Restam "+m.restam+" de ")+bo.cotas+" cotas";\n'
           + '    var f=document.querySelector("#bolaoBox .barra2 i"); if(f) f.style.width=Math.max(6,Math.round((bo.cotas-m.restam)/bo.cotas*100))+"%";\n'
           + '    var x=document.getElementById("fxR"); if(x) x.textContent="Restam "+m.restam+" de "+bo.cotas; }});\n'
           + ZJS + "/* os dados vêm do dados.json;")
_k = js.rindex("</script>"); js = js[:_k] + open("/home/claude/scripts/sons.js", encoding="utf-8").read() + open("/home/claude/scripts/sons_bl.js", encoding="utf-8").read() + js[_k:]
out = html + js
assert out.count("%%") == 2 * 10, out.count("%%")
open("/home/claude/scripts/bl_template.html", "w", encoding="utf-8").write(out)
print("modelo ok", len(out), "bytes")
