# Som da Dona Zebra: embaixadinhas, "uhhh" da torcida, relincho (rindo) e bufada.
# Linha do tempo igual à animação do bl_zebra.py.
import sys, numpy as np, scipy.signal as ss, wave

SR = 44100
DUR = 4.4
N = int(SR * DUR)
rng = np.random.default_rng(1970)
mix = np.zeros(N)

def poe(sig, t0, g):
    i = int(round(t0 * SR)); j = min(N, i + len(sig)); mix[i:j] += g * sig[: j - i]
def norm(x):
    m = np.max(np.abs(x)); return x / m if m > 0 else x
def banda(x, lo, hi, o=2):
    b, a = ss.butter(o, [lo / (SR / 2), hi / (SR / 2)], "band"); return ss.lfilter(b, a, x)
def suave(n, corte):
    b, a = ss.butter(2, corte / (SR / 2)); return norm(ss.lfilter(b, a, rng.standard_normal(n)))
def ressonador(x, F, B):
    C = -np.exp(-2 * np.pi * B / SR); Bc = 2 * np.exp(-np.pi * B / SR) * np.cos(2 * np.pi * F / SR); A = 1 - Bc - C
    y = np.zeros_like(x); y1 = y2 = 0.0
    for i in range(len(x)):
        yi = A[i] * x[i] + Bc[i] * y1 + C[i] * y2; y[i] = yi; y2 = y1; y1 = yi
    return y
def fonte(f0, rolloff, teto=6000.0, kmax=40):
    ph = 2 * np.pi * np.cumsum(f0) / SR; s = np.zeros(len(f0))
    for k in range(1, kmax):
        s += (k * f0 < teto) * np.sin(k * ph) / k ** rolloff
    return s

def chute(forte=1.0):                       # "poc" da bola
    d = .16; n = int(d * SR); t = np.arange(n) / SR
    f = 150 * np.exp(-t / .05) + 60
    corpo = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / .045)
    couro = banda(rng.standard_normal(n), 700, 3200) * np.exp(-t / .006)
    return forte * (norm(corpo) + .55 * norm(couro))

def torcida(d=1.9):                         # "uhhhh" de surpresa
    n = int(d * SR); t = np.arange(n) / SR; s = np.zeros(n)
    for v in range(26):
        f = rng.uniform(105, 270); ini = rng.uniform(0, .14)
        cont = f * (1 + .035 * np.clip((t - ini) / .3, 0, 1) - .07 * np.clip((t - ini - .7) / 1.0, 0, 1))
        cont *= 1 + rng.uniform(.008, .02) * np.sin(2 * np.pi * rng.uniform(4, 6.5) * t + rng.uniform(0, 6))
        e = np.clip((t - ini) / .22, 0, 1) * np.clip((d - t) / .9, 0, 1)
        s += fonte(cont, 1.5, teto=3500, kmax=30) * e * rng.uniform(.6, 1)
    s = norm(s)
    y = ressonador(s, np.full(n, 480.0), np.full(n, 120.0))
    y = ressonador(y, np.full(n, 880.0), np.full(n, 140.0))
    y = ressonador(y, np.full(n, 2500.0), np.full(n, 260.0))
    ar = banda(rng.standard_normal(n), 250, 3200) * (np.clip(t / .25, 0, 1) * np.clip((d - t) / 1.1, 0, 1))
    return norm(norm(y) + .15 * norm(ar)) * (0.85 + 0.15 * suave(n, 6))

def relincho(d=1.3):                        # "hiiii-hi-hi-hi" da zebra rindo
    n = int(d * SR); t = np.arange(n) / SR
    base = 1250 * (480 / 1250) ** (t / d)
    taxa = 13 - 4 * t / d
    fase = 2 * np.pi * np.cumsum(taxa) / SR
    prof = .03 + .16 * np.clip(t / (.7 * d), 0, 1)
    f0 = base * (1 + prof * np.sin(fase)) * (1 + .01 * suave(n, 30))
    s = norm(fonte(f0, 1.25, teto=7000))
    s += .18 * norm(banda(rng.standard_normal(n), 1500, 6000))
    y = ressonador(s, np.full(n, 950.0), np.full(n, 220.0))
    y = ressonador(y, np.interp(t, [0, d], [2300, 1800]), np.full(n, 260.0))
    y = ressonador(y, np.full(n, 3200.0), np.full(n, 350.0))
    pulso = .55 + .45 * (0.5 + 0.5 * np.sin(fase - .6)) ** 1.5
    e = np.clip(t / .04, 0, 1) * (1 - .55 * t / d) * np.clip((d - t) / .15, 0, 1) * pulso
    y = norm(y) * e
    return np.tanh(1.6 * y) / np.tanh(1.6)

def bufada(d=.34):                          # "brrrr" no fim
    n = int(d * SR); t = np.arange(n) / SR
    r = banda(rng.standard_normal(n), 140, 1400)
    flutter = .5 + .5 * np.sin(2 * np.pi * 27 * t) ** 2
    return norm(r * flutter * np.clip(t / .015, 0, 1) * np.exp(-t / .12))

def reverb(x, rt=.45, mol=.14):
    n = int(rt * SR); t = np.arange(n) / SR
    ir = rng.standard_normal(n) * np.exp(-t / (rt / 6.9)); b, a = ss.butter(1, 4500 / (SR / 2)); ir = ss.lfilter(b, a, ir)
    ir[: int(.012 * SR)] = 0; ir /= np.sqrt(np.sum(ir ** 2))
    w = ss.fftconvolve(x, ir)[: len(x)]; return x + mol * norm(w) * np.max(np.abs(x))

for t0 in (.10, .55, 1.00): poe(chute(), t0, .38)
poe(chute(1.3), 1.40, .42)
poe(chute(.7), 2.10, .30)
poe(chute(.35), 2.40, .22)
poe(torcida(), 1.50, .42)
poe(relincho(), 1.65, .62)
poe(bufada(), 3.25, .40)
mix = reverb(mix)
mix *= np.clip(np.arange(N) / (.004 * SR), 0, 1)
mix = .89 * mix / np.max(np.abs(mix))
with wave.open(sys.argv[1] if len(sys.argv) > 1 else "/tmp/zebra.wav", "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix * 32767).astype("<i2").tobytes())
print("ok", DUR, "s")
