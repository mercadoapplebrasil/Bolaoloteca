# Dona Zebra animada: pisca, mexe a orelha; no toque faz embaixadinhas e "Deu zebra!" rindo.
T = 4.6
def P(t): return f"{max(0.0, min(100.0, t / T * 100)):.2f}%"
def kf(nome, quadros):
    out = []
    for q in quadros:
        t, c = q[0], q[1]; fn = q[2] if len(q) > 2 else None
        out.append(f"{P(t)}{{{c}{';animation-timing-function:' + fn if fn else ''}}}")
    return "@keyframes %s{%s}" % (nome, "".join(out))
SOBE, DESCE = "cubic-bezier(.2,.75,.45,1)", "cubic-bezier(.55,0,.85,.35)"
css = ["""
.zebra{background:none;border:0;padding:0;cursor:pointer;-webkit-tap-highlight-color:transparent;font:inherit;color:inherit}
@media(max-width:719px){.zebra{position:relative;width:124px}}
@media(min-width:720px){.dz-som{bottom:6%;right:10%}}
.zebra svg{overflow:visible}
.dz-som{position:absolute;bottom:-2px;right:-6px;width:34px;height:34px;border-radius:50%;background:#fff;border:3px solid var(--red);display:flex;align-items:center;justify-content:center;font-size:15px;line-height:1;animation:dz-chama 1.6s ease-in-out infinite alternate}
@keyframes dz-chama{from{transform:scale(1)}to{transform:scale(1.12)}}
.dz-cab{transform-origin:156px 168px;animation:dz-balanca 3.2s ease-in-out infinite alternate}
.dz-olhos{transform-origin:161px 104px;animation:dz-pisca 4.6s linear infinite}
.dz-od{transform-origin:202px 62px;animation:dz-orelha 5.5s linear infinite}
.dz-oe{transform-origin:118px 62px}
.dz-bola{transform-box:fill-box;transform-origin:50% 50%}
.dz-pata{transform-origin:118px 226px}
.dz-boca{transform-origin:162px 148px}
.dz-gol{transform-origin:277px 38px;opacity:0}
@keyframes dz-balanca{from{transform:rotate(-2deg)}to{transform:rotate(2deg)}}
@keyframes dz-pisca{0%,93%,97%,100%{transform:scaleY(1)}95%{transform:scaleY(.1)}}
@keyframes dz-orelha{0%,88%,97%,100%{transform:rotate(0)}91%{transform:rotate(14deg)}94%{transform:rotate(-5deg)}}
.balao.pop{animation:dz-pop .45s cubic-bezier(.2,.9,.3,1.4)}
@keyframes dz-pop{0%{transform:scale(.6)}100%{transform:scale(1)}}
"""]
regras = []
def anima(sel, nome, quadros, fn="linear"):
    css.append(kf(nome, quadros)); regras.append(f".dz.show {sel}{{animation:{nome} {T}s {fn} both}}")

# Dona Zebra joga a bola para o alto e faz um gol de cabeça
B = lambda x, y, r, sc=1: f"transform:translate({x}px,{y}px) rotate({r}deg) scale({sc})"
anima(".dz-bola", "dz-bola", [(0, B(0, 0, 0) + ";opacity:1"), (.2, B(0, 0, 0), SOBE), (.68, B(46, -267, 200, .9), DESCE), (1.1, B(94, -240, 330, .9), "cubic-bezier(.3,.6,.6,1)"),
                              (1.6, B(223, -224, 620, .3) + ";opacity:1"), (3.5, B(223, -216, 620, .3) + ";opacity:1"), (3.7, B(223, -216, 620, .3) + ";opacity:0"),
                              (3.75, B(0, 0, 0) + ";opacity:0"), (4.05, B(0, 0, 0) + ";opacity:1"), (T, B(0, 0, 0) + ";opacity:1")])
R = lambda a: f"transform:rotate({a}deg)"
anima(".dz-pata", "dz-pata", [(0, R(0)), (.12, R(9)), (.26, R(-30)), (.6, R(0)), (T, R(0))])
TR = lambda x, y: f"transform:translate({x}px,{y}px)"
anima(".dz-pup", "dz-pup", [(0, TR(0, 0)), (.1, TR(-4, 5)), (.35, TR(-4, -6)), (.7, TR(-2, -7)), (1.1, TR(0, -7)), (1.5, TR(5, -6)), (2.0, TR(5, -6)),
                            (2.3, TR(0, 0)), (T, TR(0, 0))])
S = lambda s: f"transform:scale({s})"
anima(".dz-olhos", "dz-olhos", [(0, S(1)), (1.5, S(1)), (1.62, S(1.16)), (3.15, S(1.16)), (3.3, S(1)), (T, S(1))])
anima(".dz-sob", "dz-sob", [(0, TR(0, 0)), (.3, TR(0, -5)), (1.5, TR(0, -5)), (1.62, TR(0, -9)), (3.15, TR(0, -9)), (3.3, TR(0, 0)), (T, TR(0, 0))])
C = lambda y, a: f"transform:translateY({y}px) rotate({a}deg)"
cab = [(0, C(0, 0)), (.3, C(0, -3)), (.85, C(4, -3)), (1.02, C(12, -5)), (1.1, C(-18, 7)), (1.3, C(-4, 3)), (1.5, C(0, 0)), (1.75, C(0, -3))]
t, lado = 1.75, 1
while t < 3.0:
    t += .12; cab.append((round(t, 2), C(-4 if lado > 0 else 0, 6 * lado))); lado = -lado
cab += [(3.1, C(0, 0)), (3.3, C(0, 5)), (3.5, C(0, -1)), (3.7, C(0, 0)), (T, C(0, 0))]
anima(".dz-cab", "dz-cab", cab)
boca = [(0, "transform:scaleY(1)"), (1.6, "transform:scaleY(1)"), (1.72, "transform:scaleY(1.8)")]
t, ab = 1.72, False
while t < 3.0:
    t += .12; boca.append((round(t, 2), f"transform:scaleY({1.8 if ab else 1.3})")); ab = not ab
boca += [(3.1, "transform:scaleY(1)"), (T, "transform:scaleY(1)")]
anima(".dz-boca", "dz-boca", boca)
for cls, sinal in ((".dz-oe", -1), (".dz-od", 1)):
    q = [(0, R(0)), (1.7, R(0))]; t, ab = 1.7, True
    while t < 3.0:
        t += .12; q.append((round(t, 2), R(sinal * (12 if ab else -4)))); ab = not ab
    q += [(3.1, R(0)), (T, R(0))]
    anima(cls, "dz" + cls.replace(".", "-"), q)
anima(".dz-gol", "dz-gol", [(0, "opacity:0;transform:scale(.6)"), (.75, "opacity:0;transform:scale(.6)"), (1.0, "opacity:1;transform:scale(1.08)"), (1.1, "opacity:1;transform:scale(1)"),
                            (3.6, "opacity:1;transform:scale(1)"), (3.9, "opacity:0;transform:scale(.6)"), (T, "opacity:0;transform:scale(.6)")])
anima(".dz-rede", "dz-rede", [(0, TR(0, 0)), (1.58, TR(0, 0)), (1.66, TR(7, -2)), (1.76, TR(-4, 1)), (1.86, TR(3, 0)), (1.96, TR(0, 0)), (T, TR(0, 0))])
css += regras
css.append("@media (prefers-reduced-motion:reduce){.dz-som,.dz-cab,.dz-olhos,.dz-od,.balao.pop{animation:none}}")

svg = '''<svg class="dz" viewBox="0 0 300 320" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <clipPath id="zc"><path d="M150 150c-18 0-30 14-32 40l-4 130h74l-6-130c-2-26-14-40-32-40z"/></clipPath>
        <clipPath id="zh"><ellipse cx="160" cy="110" rx="66" ry="60"/></clipPath>
      </defs>
      <g class="dz-gol"><g class="dz-rede" stroke="#fff" stroke-width="1.6" opacity=".7"><path d="M242 8V70M256 8V70M270 8V70M284 8V70M298 8V70M312 8V70M229 20H325M229 33H325M229 46H325M229 59H325"/></g><path d="M228 72V6H326V72" fill="none" stroke="#fff" stroke-width="6" stroke-linejoin="round" stroke-linecap="round"/></g>
      <path d="M150 150c-18 0-30 14-32 40l-4 130h74l-6-130c-2-26-14-40-32-40z" fill="#F6F2EC" stroke="#121212" stroke-width="6"/>
      <g clip-path="url(#zc)" fill="#121212"><path d="M100 196h100l-6 16H106z M102 230h100l-6 16H108z M104 264h100l-6 16H110z M106 298h100l-6 22H112z"/></g>
      <g class="dz-cab">
      <path d="M118 70l-14-30 24 18 2-32 14 26 10-30 8 30 12-24-2 34 18-14-10 30z" fill="#121212"/>
      <ellipse cx="160" cy="110" rx="66" ry="60" fill="#F6F2EC" stroke="#121212" stroke-width="6"/>
      <g clip-path="url(#zh)" fill="#121212"><path d="M90 60l44-6 2 12-44 8z M96 86l36-8 3 10-36 10z M220 72l-30 10 6 10 28-12z M224 100l-26 6 4 10 24-8z"/></g>
      <g class="dz-oe"><path d="M118 62l-20-40 36 24z" fill="#F6F2EC" stroke="#121212" stroke-width="6" stroke-linejoin="round"/><path d="M116 56l-10-20 18 12z" fill="#D5261F"/></g>
      <g class="dz-od"><path d="M202 62l20-40-36 24z" fill="#F6F2EC" stroke="#121212" stroke-width="6" stroke-linejoin="round"/><path d="M204 56l10-20-18 12z" fill="#D5261F"/></g>
      <g class="dz-olhos">
      <ellipse cx="138" cy="104" rx="18" ry="21" fill="#fff" stroke="#121212" stroke-width="5"/>
      <ellipse cx="184" cy="104" rx="18" ry="21" fill="#fff" stroke="#121212" stroke-width="5"/>
      <g class="dz-pup"><circle cx="142" cy="108" r="8" fill="#121212"/><circle cx="188" cy="108" r="8" fill="#121212"/>
      <circle cx="145" cy="104" r="3" fill="#fff"/><circle cx="191" cy="104" r="3" fill="#fff"/></g>
      </g>
      <path class="dz-sob" d="M118 80c8-8 20-10 30-6 M172 74c10-4 22-2 30 6" fill="none" stroke="#121212" stroke-width="5" stroke-linecap="round"/>
      <ellipse cx="162" cy="150" rx="44" ry="26" fill="#F6F2EC" stroke="#121212" stroke-width="6"/>
      <path class="dz-boca" d="M130 148c16 16 48 16 64 0-8 24-56 24-64 0z" fill="#D5261F" stroke="#121212" stroke-width="4"/>
      <circle cx="144" cy="138" r="5" fill="#121212"/><circle cx="180" cy="138" r="5" fill="#121212"/>
      </g>
      <path class="dz-pata" d="M118 214c-26-2-48 4-62 18 14 10 36 12 60 6z" fill="#F6F2EC" stroke="#121212" stroke-width="6"/>
      <g class="dz-bola">
      <circle cx="54" cy="262" r="44" fill="#fff" stroke="#121212" stroke-width="6"/>
      <path d="M54 232l17 12-6 20H43l-6-20z" fill="#121212"/>
      <path d="M71 244l19-6 7 18-12 12-8-4z M37 244l-19-6-7 18 12 12 8-4z M48 264l-9 16 9 16h12l9-16-9-16z" fill="#121212"/>
      <path d="M54 232l-1-14 M71 244l17-12 M37 244l-17-12 M78 268l15 8 M30 268l-15 8" stroke="#121212" stroke-width="4" stroke-linecap="round"/>
      </g>
    </svg>'''
open("/home/claude/scripts/bl_zebra.css", "w", encoding="utf-8").write("\n".join(css))
open("/home/claude/scripts/bl_zebra.svg", "w", encoding="utf-8").write(svg)
print("zebra ok", sum(len(c) for c in css), "bytes de css")
