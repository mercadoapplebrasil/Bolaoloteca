/* Dona Zebra: joga a bola para o alto, gol de cabeça e "Deu zebra!" (o som só toca no toque, regra do navegador) */
(function(){
function ligaSom(b,au,inicia,ativo){
  if(!b)return;
  function est(t){b.classList.toggle("on",t);if(t)b.classList.add("min");b.setAttribute("aria-pressed",t?"true":"false");b.setAttribute("aria-label",t?"Pausar o som":"Toque pra tocar o som");}
  au.addEventListener("playing",function(){if(ativo())est(true);});
  ["pause","ended"].forEach(function(e){au.addEventListener(e,function(){est(false);});});
  b.addEventListener("click",function(ev){ev.stopPropagation();if(b.classList.contains("on")){try{au.pause();}catch(x){}}else{b.classList.add("min");inicia();}});
  setTimeout(function(){b.classList.add("min");},7000);
}
  var bt=document.getElementById("dz"); if(!bt) return;
  var svg=bt.querySelector("svg"), bal=document.getElementById("balao");
  var reduz=!!(window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  var au=new Audio(); au.preload="none"; au.src="zebra.mp3";
  var tms=[], orig=null;
  function volta(){ if(orig!==null){ bal.textContent=orig; orig=null; } bal.classList.remove("pop"); }
  function show(){
    tms.forEach(clearTimeout); tms=[]; volta();
    if(!reduz){ svg.classList.remove("show"); void svg.getBoundingClientRect(); svg.classList.add("show"); }
    tms.push(setTimeout(function(){ orig=bal.textContent; bal.textContent="GOOOL! Deu zebra! 🦓"; void bal.offsetWidth; bal.classList.add("pop"); }, reduz?0:1640));
    tms.push(setTimeout(function(){ svg.classList.remove("show"); }, 4700));
    tms.push(setTimeout(volta, 6600));
  }
  var comSom=false;
  function toca(){
    var foi=false; comSom=true; function vai(){ if(!foi){ foi=true; show(); } }
    try{ au.currentTime=0; }catch(e){}
    var p=null; try{ p=au.play(); }catch(e){}
    if(p&&p.then){ p.then(vai,vai); setTimeout(vai,900); } else vai();
  }
  bt.addEventListener("click",toca);
  ligaSom(document.getElementById("somb"),au,toca,function(){return comSom;});
  /* a primeira passada é quando a zebra aparece na tela (ela fica abaixo do cartão do bolão) */
  if(!reduz){ if("IntersectionObserver" in window) new IntersectionObserver(function(es,o){ if(es[0].isIntersecting){ o.disconnect(); setTimeout(show,500); } },{threshold:.6}).observe(bt); else setTimeout(show,1400); }
  /* o som só baixa depois que a página terminou de carregar, pra não disputar banda com o conteúdo */
  var arma=function(){ setTimeout(function(){ if("IntersectionObserver" in window) new IntersectionObserver(function(es,o){ if(es[0].isIntersecting){ au.preload="auto"; try{au.load();}catch(e){} o.disconnect(); } }).observe(bt); },2500); };
  if(document.readyState==="complete")arma(); else window.addEventListener("load",arma);
})();
