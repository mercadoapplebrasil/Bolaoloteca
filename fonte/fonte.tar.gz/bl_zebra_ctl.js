/* Dona Zebra: embaixadinhas e "Deu zebra!" (o som só toca no toque, regra do navegador) */
(function(){
  var bt=document.getElementById("dz"); if(!bt) return;
  var svg=bt.querySelector("svg"), bal=document.getElementById("balao");
  var reduz=!!(window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  var au=new Audio(); au.preload="none"; au.src="zebra.mp3";
  var tms=[], orig=null;
  function volta(){ if(orig!==null){ bal.textContent=orig; orig=null; } bal.classList.remove("pop"); }
  function show(){
    tms.forEach(clearTimeout); tms=[]; volta();
    if(!reduz){ svg.classList.remove("show"); void svg.getBoundingClientRect(); svg.classList.add("show"); }
    tms.push(setTimeout(function(){ orig=bal.textContent; bal.textContent="Deu zebra! 🦓"; void bal.offsetWidth; bal.classList.add("pop"); }, reduz?0:1550));
    tms.push(setTimeout(function(){ svg.classList.remove("show"); }, 4700));
    tms.push(setTimeout(volta, 6600));
  }
  bt.addEventListener("click",function(){
    var foi=false; function vai(){ if(!foi){ foi=true; show(); } }
    try{ au.currentTime=0; }catch(e){}
    var p=null; try{ p=au.play(); }catch(e){}
    if(p&&p.then){ p.then(vai,vai); setTimeout(vai,900); } else vai();
  });
  if(!reduz) setTimeout(show,1400);
  if("IntersectionObserver" in window) new IntersectionObserver(function(es,o){ if(es[0].isIntersecting){ au.preload="auto"; try{au.load();}catch(e){} o.disconnect(); } }).observe(bt);
})();
