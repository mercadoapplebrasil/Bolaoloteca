# Monta o Bolão Loteca a partir do modelo (bl_template.html) e do dados.json.
#   python3 build_bl.py previa  -> novo/index.html (noindex)
#   python3 build_bl.py final   -> index.html na raiz
# O conteúdo (topo, card do bolão e os 14 jogos) já sai escrito no HTML; no navegador o
# script relê o dados.json e atualiza contagem, cotas e resultados.
import sys, os, json, shutil, threading, functools, datetime
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
REPO, SC = "/home/claude/bolaoloteca", "/home/claude/scripts"
modo = sys.argv[1] if len(sys.argv) > 1 else "previa"
pasta = REPO if modo == "final" else REPO + "/novo"
if modo == "final" and not os.path.exists(REPO + "/dados.json"):
    shutil.copy(REPO + "/novo/dados.json", REPO + "/dados.json")
dados = json.load(open(pasta + "/dados.json", encoding="utf-8"))
import subprocess
for cmd in (["python3", SC + "/bl_zebra.py"], ["python3", SC + "/bl_fazer_template.py"], ["python3", SC + "/bl_som_zebra.py", "/tmp/zebra.wav"],
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", "/tmp/zebra.wav", "-codec:a", "libmp3lame", "-b:a", "80k", "-ac", "1", pasta + "/zebra.mp3"]):
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL)
tpl = open(SC + "/bl_template.html", encoding="utf-8").read()
VAZIO = {"HEYE": "", "HCONC": "", "HPREMIO": "", "HSUB": "", "BOLAO": "", "GRADESUB": "", "GRADE": "",
         "CONF": '<div class="conf" id="conf" hidden></div>'}
def montar(v):
    out = tpl.replace("%%ROBOTS%%", '<meta name="robots" content="noindex">\n' if modo != "final" else "")
    out = out.replace("%%DADOS%%", json.dumps(dados, ensure_ascii=False).replace("<", "\\u003c"))
    for k, x in v.items(): out = out.replace("%%" + k + "%%", x)
    assert "%%" not in out
    return out
dest = pasta + "/index.html"
open(dest, "w", encoding="utf-8").write(montar(VAZIO))

class Quieto(SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Quieto, directory=REPO))
threading.Thread(target=srv.serve_forever, daemon=True).start()
url = f"http://127.0.0.1:{srv.server_address[1]}/" + ("" if modo == "final" else "novo/")
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
    pg = b.new_page(viewport={"width": 390, "height": 844})
    pg.goto(url, wait_until="networkidle")
    pg.wait_for_function("document.querySelector('#listaGrade li') && document.getElementById('bolaoBox').children.length", timeout=8000)
    v = pg.evaluate("""()=>{const g=id=>document.getElementById(id).innerHTML;
      return {HEYE:g('hEye'),HCONC:g('hConc'),HPREMIO:g('hPremio'),HSUB:g('hSub'),BOLAO:g('bolaoBox'),
              GRADESUB:g('gradeSub'),GRADE:g('listaGrade'),CONF:document.getElementById('conf').outerHTML};}""")
    b.close()
srv.shutdown()
open(dest, "w", encoding="utf-8").write(montar(v))
print(dest, os.path.getsize(dest), "bytes ·", v["GRADE"].count('class="jg'), "jogos no HTML")

if modo == "final":
    hoje = datetime.date.today().isoformat()
    open(REPO + "/sitemap.xml", "w", encoding="utf-8").write(
        '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        f'  <url><loc>https://bolaoloteca.com.br/</loc><lastmod>{hoje}</lastmod><changefreq>daily</changefreq></url>\n</urlset>\n')
    open(REPO + "/robots.txt", "w", encoding="utf-8").write("User-agent: *\nAllow: /\nDisallow: /fonte/\n\nSitemap: https://bolaoloteca.com.br/sitemap.xml\n")
    for f in ("dados.json", "zebra.mp3"):
        if os.path.exists(REPO + "/novo/" + f): os.remove(REPO + "/novo/" + f)
    open(REPO + "/novo/index.html", "w", encoding="utf-8").write(
        '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>Bolão Loteca</title>'
        '<meta name="robots" content="noindex"><link rel="canonical" href="https://bolaoloteca.com.br/">'
        '<meta http-equiv="refresh" content="0; url=/"><script>location.replace("/"+location.hash)</script></head>'
        '<body><a href="/">Ir para o Bolão Loteca</a></body></html>\n')
    open(REPO + "/README.md", "w", encoding="utf-8").write("""# Bolão Loteca

Site do bolão da Loteca: https://bolaoloteca.com.br

## Atualizar

Tudo fica no `dados.json`: `concurso`, `premio`, `especial`, `fechamento` (com `-03:00`), `prazos`, `bolao` (`formato`, `cotas`, `restam`, `valor` e, se houver, `app`) e os 14 `jogos` (`casa`, `fora`, `quando`, `b` = palpite do bolão, como "1", "1X" ou "1X2").

Depois dos jogos, preencha em cada jogo `r` ("1", "X" ou "2") e `placar` ("2 x 1"): a conferência do bolão aparece sozinha. As cotas só mudam com o print oficial da Caixa.

O `index.html` é montado por script e já traz o conteúdo escrito (melhor para o Google). Se só o `dados.json` mudar, o site continua certo: o navegador relê o arquivo ao abrir.
""")
    print("sitemap.xml, robots.txt, README e atalho /novo prontos")
