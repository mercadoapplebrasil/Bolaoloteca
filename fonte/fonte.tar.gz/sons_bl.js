document.addEventListener("click",function(e){ if(!window.SOM) return; var t=e.target;
  if(t.closest&&t.closest("#dz")) return;
  var x=t.closest&&t.closest("#btnHist,.btn.exp,[aria-expanded]"); if(x){ x.getAttribute("aria-expanded")==="true"?SOM.fecha():SOM.abre(); return; }
  if(t.closest&&t.closest(".btn,.chip,.vi,.lk,.fixa a,.av button.fx,.av a")) SOM.plim(); },true);
